from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Brands)
admin.site.register(Contactusquery)
admin.site.register(UserDetails)
admin.site.register(Vehicles)
admin.site.register(Booking)
